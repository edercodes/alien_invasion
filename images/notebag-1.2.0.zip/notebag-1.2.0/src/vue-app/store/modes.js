export default {
	EDITOR: "editor",
	NOTES: "notes",
	CATEGORIES: "categories",
	ARCHIVE: "archive",
};
