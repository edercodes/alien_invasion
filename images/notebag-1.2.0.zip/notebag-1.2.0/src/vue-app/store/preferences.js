export default {
	NOTE_PANE_WIDTH: "notePaneWidth",
	THEME: "theme",
	NOTE_PATH: "notePath",
	SHORTCUTS: "shortcuts",
	SHOW_DOCK: "showDock",
	FONT_SIZE: "fontSize",
};
