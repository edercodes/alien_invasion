export default {
	MOVE_UP: "up",
	MOVE_DOWN: "down",

	THEME_LIGHT: "light",
	THEME_DARK: "dark",
};
