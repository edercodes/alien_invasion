export default [
	{
		"identifier": "omnibar-0cd35trlh",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3"
	},
	{
		"identifier": "omnibar-2qmsiome1",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3"
	},
	{
		"identifier": "keyboard-shortcuts-ry0twfpa4",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "f5564878-7150-4487-b792-f5bda2d75d44"
	},
	{
		"identifier": "organizing-your-notes-zn4rtms5q",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "231363ed-3698-4a0c-8596-f8ebf2313c30"
	},
	{
		"identifier": "organizing-your-notes-iwbie2kzn",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "231363ed-3698-4a0c-8596-f8ebf2313c30"
	},
	{
		"identifier": "markdown-formatting-sng316uvz",
		"originNote": "8996834f-5e63-4898-9255-ca9e8765e5cd",
		"targetNote": "f5fdb941-6c1d-4c18-8823-0b7efee054c9"
	},
	{
		"identifier": "organizing-your-notes-8jbr46wom",
		"originNote": "f5fdb941-6c1d-4c18-8823-0b7efee054c9",
		"targetNote": "231363ed-3698-4a0c-8596-f8ebf2313c30"
	},
	{
		"identifier": "introduction-to-note-taking-i5yymc6wi",
		"originNote": "231363ed-3698-4a0c-8596-f8ebf2313c30",
		"targetNote": "8996834f-5e63-4898-9255-ca9e8765e5cd"
	},
	{
		"identifier": "omnibar-t5ddzidzt",
		"originNote": "231363ed-3698-4a0c-8596-f8ebf2313c30",
		"targetNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3"
	},
	{
		"identifier": "markdown-formatting-5jrx3l66v",
		"originNote": "231363ed-3698-4a0c-8596-f8ebf2313c30",
		"targetNote": "f5fdb941-6c1d-4c18-8823-0b7efee054c9"
	},
	{
		"identifier": "omnibar-lz770dbq2",
		"originNote": "f5564878-7150-4487-b792-f5bda2d75d44",
		"targetNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3"
	},
	{
		"identifier": "omnibar-ph8kd3e1m",
		"originNote": "f5564878-7150-4487-b792-f5bda2d75d44",
		"targetNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3"
	},
	{
		"identifier": "keyboard-shortcuts-eattocaze",
		"originNote": "c3ff7a0c-667b-41cc-af3b-285f77d8c5a3",
		"targetNote": "f5564878-7150-4487-b792-f5bda2d75d44"
	}
];
